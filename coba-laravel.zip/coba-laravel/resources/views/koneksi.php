<?php
$servername = "localhost";
$username ="root";
$password ="";
$dbname = "user_github";

$conn = mysqli_connect($servername, $username, $password, $dbname);

?>