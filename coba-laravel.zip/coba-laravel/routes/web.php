<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home', [
        "title" => "Home"
    ]);
});

Route::get('/about', function () {
    return view('about', [
        "title" => "About",
        "name" => "Nisa Wirasyah",
        "email" => "nisawirasyah@student.telkomuniversity.ac.id",
        "image" => "Photo Denis.jpg"
    ]);
});

Route::get('/blog', function () {
    $blog_post = [
        [
            "title" => "Judul Post Pertama",
            "author" => "Nisa Wirasyah",
            "body" => "Lorem, ipsum dolor sit amet consectetur adipisicing elit. Obcaecati harum voluptatem exercitationem corporis. Optio alias saepe harum placeat sed ut, quae ad facilis, illum quis pariatur. Vero placeat praesentium assumenda exercitationem autem perspiciatis illo provident quaerat unde, eum vitae illum adipisci mollitia voluptatem aperiam ex dolor similique veritatis? Dolorem, quae iusto dolorum fugiat natus, voluptates quas placeat debitis magnam quidem neque aliquam officia eum maxime veniam, mollitia sit autem ducimus similique. Modi, libero. Omnis, laudantium quo sapiente eveniet officiis libero?"
        ],
        [
            "title" => "Judul Post Kedua",
            "author" => "Steven Choi",
            "body" => "Lorem ipsum dolor sit amet consectetur adipisicing elit. Natus vel eveniet laborum autem nisi incidunt? Porro dolore nisi natus ullam quas laboriosam eos iusto nobis, totam quis ducimus consequatur ut quam quo illo quos sint placeat cumque officiis quaerat. Sequi facilis atque sunt eos beatae earum voluptas consectetur quaerat eligendi maxime. Est perspiciatis dolorum adipisci, ipsam veniam aliquid ut, pariatur sequi nam deserunt repellat sapiente? Nisi fuga vero excepturi nesciunt accusantium? Laboriosam facere consequatur, repudiandae nisi voluptatem ex ipsam non illo velit minus nulla voluptates quam officia voluptatum eos consequuntur rem? Nesciunt, minus? Rerum, quo deserunt! Cupiditate eius facere impedit."
        ],
    ];
    
    return view('posts', [
        "title" => "Blog",
        "posts" => $blog_post
    ]);
});
